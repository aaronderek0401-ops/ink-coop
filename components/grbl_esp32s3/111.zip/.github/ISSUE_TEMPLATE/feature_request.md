---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Please describe the feature you would like implemented**

**Why do you think this would improve Grbl_ESP32?**

**What do you need the feature for?**

**Will this feature appear to a lot of users?**
