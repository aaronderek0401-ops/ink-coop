

#define MACHINE_NAME "Longer Laser ray5"
#define VERSION "2024-03-15"
#define DEFAULT_VERBOSE_ERRORS 1

#define HTTP_PORT_8848

#define STEPPERS_DISABLE_PIN GPIO_NUM_3

#define X_LIMIT_PIN GPIO_NUM_6
#define X_STEP_PIN GPIO_NUM_14
#define X_DIRECTION_PIN GPIO_NUM_9

#define Y_LIMIT_PIN GPIO_NUM_5
#define Y_STEP_PIN GPIO_NUM_16
#define Y_DIRECTION_PIN GPIO_NUM_15

#define SPINDLE_TYPE SpindleType::LASER
#define LASER_OUTPUT_PIN GPIO_NUM_7
#define DEFAULT_LASER_MODE 1

#define ENABLE_SD_CARD
#define SDCARD_DET_PIN GPIO_NUM_48
// #define SDCARD_CS_PIN GPIO_NUM_10    


#define BUZZER_PIN GPIO_NUM_1  // labeled buzzer

#define MOTION_PIN GPIO_NUM_8    // labeled motion sensor
#define MOTION_TAP_THRES 170      // the larger value, the more insensitive
#define MOTION_TAP_DUR 200         // the smaller value, the more insensitive
#define PIN_MOTION_USE_INTERRUPT  // commment to use polling mode

#define FLAME_PIN GPIO_NUM_4          // labeled flame sensor
#define PIN_FLAME_USE_ADC 1         // comment to use digital read method for FLAME sensor
#define FLAME_ADC_CHANNEL ADC1_CHANNEL_3  // set ADC channel
#define FLAME_ADC_THRES 2500        // the smaller value, the more insensitive
#define FLAME_CHECK_TIMES_THRES 5   // > FLAME_CHECK_TIMES_THRES, then triggered. the larger value, the more insensitive
// #define PIN_FLAME_USE_INTERRUPT

#define TEMPERATURE_DEBUG
#define TEMPERATURE_PIN GPIO_NUM_2
#define PIN_EMPERATURE_USE_ADC 1
#define TEMPERATURE_ADC_CHANNEL ADC1_CHANNEL_1  // set ADC channel
#define TEMPERATURE_ADC_THRES 1700  
#define TEMPERATURE_CHECK_TIMES_THRES 5     //Used to set the threshold of temperature detection times.

#define PIN_I2C_SCL GPIO_NUM_17
#define PIN_I2C_SDA GPIO_NUM_18

// #define COOLANT_FLOOD_PIN GPIO_NUM_21

/////////////////////////

#define DEFAULT_HOMING_ENABLE 1
#define DEFAULT_HOMING_CYCLE_0 (bit(X_AXIS) | bit(Y_AXIS))
#define DEFAULT_HARD_LIMIT_ENABLE 1
#define DEFAULT_SOFT_LIMIT_ENABLE 0

// #define N_AXIS 3

#define DEFAULT_LASER_FULL_POWER 1000
#define DEFAULT_SPINDLE_RPM_MAX 1000.0  // rpm
#define DEFAULT_SPINDLE_FREQ 1000.0     // $33 Hz (extended set)

#define DEFAULT_STEP_PULSE_MICROSECONDS 10  // $0
#define DEFAULT_STEPPER_IDLE_LOCK_TIME 250  // $1 msec (0-254, 255 keeps steppers enabled)

#define DEFAULT_DIRECTION_INVERT_MASK 0  // $3 uint8_ XYZ 000

#define DEFAULT_HOMING_FEED_RATE 200.0      // $24 mm/min  ���㲽���ٶ�
#define DEFAULT_HOMING_SEEK_RATE 2000.0     // $25 mm/min

#define DEFAULT_X_STEPS_PER_MM 80.0  //$100 X-axis travel resolution  ��ʾX�����?1mm��Ҫ80������
#define DEFAULT_Y_STEPS_PER_MM 80.0  //$101 Y-axis travel resolution  ��ʾY�����?1mm��Ҫ80������

#define DEFAULT_X_MAX_RATE 6000.0//$110 X������ٶ�?
#define DEFAULT_Y_MAX_RATE 6000.0//$111 Y������ٶ�?

#define DEFAULT_X_ACCELERATION 500.0//$120 X����ٶ�?
#define DEFAULT_Y_ACCELERATION 500.0//$121 Y����ٶ�?

#define DEFAULT_X_MAX_TRAVEL 400.0//$130 X������г�?
#define DEFAULT_Y_MAX_TRAVEL 400.0//$131 Y������г�?
