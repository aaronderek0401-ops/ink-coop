#include "src/Grbl.h"
#include "src/Machines/lgt_ray5_v_0_1.h"
#include "buzzer/buzzer.h"

void suspend_laser_init();