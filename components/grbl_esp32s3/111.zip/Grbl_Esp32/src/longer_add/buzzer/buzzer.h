#pragma once

#include "src/Grbl.h"
#include "src/Machines/lgt_ray5_v_0_1.h"

extern void buzzer_init();
extern void BuzzerON();
extern void turnOffBuzzer();
extern void turnOnBuzzer();