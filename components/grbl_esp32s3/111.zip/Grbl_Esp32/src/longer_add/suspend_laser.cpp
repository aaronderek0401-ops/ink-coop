#include "suspend_laser.h"

#define STEP_TIMER_GROUP  TIMER_GROUP_1
#define STEP_TIMER_INDEX  TIMER_1

static size_t count = 0;
static int16_t CurrentPosX = 0, CurrentPosY = 0;

// 定时器中断处理函数
void IRAM_ATTR  timer_interrupt_handler(void *arg)
{
    //获取定时器分组0中的哪一个定时器产生了中断
    uint32_t timer_intr = timer_group_get_intr_status_in_isr(STEP_TIMER_GROUP); //获取中断状态
    if (timer_intr & TIMER_INTR_T1)
    {
        //定时器0分组的0号定时器产生中断
        /*清除中断状态*/
        timer_group_clr_intr_status_in_isr(STEP_TIMER_GROUP, STEP_TIMER_INDEX);
        /*重新使能定时器中断*/
        timer_group_enable_alarm_in_isr(STEP_TIMER_GROUP, STEP_TIMER_INDEX);
        if (sys.state != State::Alarm && sys.state != State::Homing && sys.state != State::Idle)
        {
            if (sys_rt_exec_alarm == ExecAlarm::None) 
            {
                if(CurrentPosX == sys_position[0] && CurrentPosY == sys_position[1])
                {
                    grbl_msg_sendf(CLIENT_ALL, MsgLevel::Info, "!!!Warning!!! The laser state is abnormal!!");
                    BuzzerON();
                    spindle->deinit();                            
                    sys_rt_exec_alarm = ExecAlarm::SUSPEND_LASER; 
                }
            }
        }   
    }
}

void suspend_laser_init()
{
    // 配置定时器参数
    timer_config_t config;
    config.divider      = 2;                    // 分频系数，定时器时钟 = APB_CLK_FREQ / divider
    config.counter_dir  = TIMER_COUNT_UP;       // 计数方向：向上计数
    config.counter_en   = TIMER_PAUSE;          // 计数器启用状态：暂停
    config.alarm_en     = TIMER_ALARM_EN;       // 定时器报警使能
    config.intr_type    = TIMER_INTR_LEVEL;     // 中断类型：电平触发中断
    config.auto_reload  = TIMER_AUTORELOAD_EN;  // 自动重新加载计数器
    config.clk_src      = TIMER_SRC_CLK_APB;    // 选择总线时钟

    // 初始化定时器
    timer_init(STEP_TIMER_GROUP, STEP_TIMER_INDEX, &config);

    /*设置定时器预装值*/
    timer_set_counter_value(STEP_TIMER_GROUP, STEP_TIMER_INDEX, 0x00000000ULL);

    // 设置定时器的周期性中断时间
    timer_set_alarm_value(STEP_TIMER_GROUP, STEP_TIMER_INDEX, 5000 * (TIMER_BASE_CLK / 2 / 1000));

    //定时器中断使能
    timer_enable_intr(STEP_TIMER_GROUP, STEP_TIMER_INDEX);

    // 注册定时器中断处理函数
    timer_isr_register(STEP_TIMER_GROUP, STEP_TIMER_INDEX, timer_interrupt_handler, NULL, ESP_INTR_FLAG_IRAM, NULL);

    // 启动定时器
    timer_start(STEP_TIMER_GROUP, STEP_TIMER_INDEX);

    CurrentPosX = sys_position[0];
    CurrentPosY = sys_position[1];   
}