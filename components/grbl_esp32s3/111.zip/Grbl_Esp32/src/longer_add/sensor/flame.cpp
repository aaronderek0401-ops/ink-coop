#include "flame.h"

// #define DEBUG_MODE
char gcode[100];
char TJC_STR[100];
// flame pin initialization routine.
// #ifdef PIN_FLAME_USE_INTERRUPT
//   static bool flameTriggered = false;
//   void flameSensorISR(){
//     flameTriggered = true;
//     }
// #endif


void FlameSensor_init(){

  adc1_config_width(ADC_WIDTH_BIT_12);          // ���� ADC λ��Ϊ 12 λ
  adc1_config_channel_atten(FLAME_ADC_CHANNEL, ADC_ATTEN_DB_11);  // ���� ADC ��������Ϊ 11 dB

  grbl_msg_sendf(CLIENT_ALL, MsgLevel::Info, "FlameSensor on pin %s", pinName(FLAME_PIN).c_str());
  xTaskCreate(FlameCheckTask,
            "FlameCheckTask",
            2048,
            NULL,
            6,  // priority
            NULL);
}

void handleOnFlameTriggered()
{
#ifndef DEBUG_MODE
  if (sys.state != State::Alarm && sys.state != State::Homing) {
      if (sys_rt_exec_alarm == ExecAlarm::None) {
          grbl_msg_sendf(CLIENT_ALL, MsgLevel::Info, "!!!Warning!!! --------Flame sensor");
          delay(100);
          mc_reset();  // Initiate system kill.
          // sys_rt_exec_alarm = ExecAlarm::HardLimit;  // Indicate hard limit critical event
          //�������
          // mc_homing_cycle( 0 );                      // Homing

          //������
          Serial.print("[WARNING]flaeme sensor on\xff\xff\xff\r\n");
          sys_rt_exec_alarm = ExecAlarm::FLAME;  // Indicate hard limit critical event
        //   sprintf(gcode, "g90x0y0\r\n");
        //   gc_execute_line(gcode, CLIENT_SERIAL);
          //Serial.println("g90x0y0", HEX)
      }
  }
#endif
#ifdef BUZZER_PIN

  BuzzerON();
#endif

}

void flameSensorLoop(){
    // #ifdef PIN_FLAME_USE_INTERRUPT
    //     if (flameTriggered) {

    //       handleOnFlameTriggered();          
    //       flameTriggered = false;           // clear flag
    
    //     }
    //     #endif   
    // if (analogRead(FLAME_PIN) < FLAME_ADC_THRES) {

    // ʹ�� ADC ���� AD ���
    uint32_t adcValue = adc1_get_raw(FLAME_ADC_CHANNEL);

    // ��ӡ AD ֵ
    // Serial.print("ADC Value: ");
    // Serial.println(adcValue);
    // if(digitalRead(2))
    // {
    //   digitalWrite(2, LOW);
    // }else{
    //   digitalWrite(2, HIGH);
    // }
    static int checkCount = 0;
    if (PIN_FLAME_USE_ADC) {
      const int frameRawReadTimes = 5;
      long frameRawSum = 0;
      
      for (int i = 0; i < frameRawReadTimes; i++)
        frameRawSum += adc1_get_raw(FLAME_ADC_CHANNEL);

      int frameRawRead = frameRawSum / frameRawReadTimes;

      if (frameRawRead < FLAME_ADC_THRES) { 
        if (checkCount > -1) {
          checkCount++;
          #ifdef DEBUG_MODE
            Serial.print("frame: checked adc:");
            Serial.print(frameRawRead);
            Serial.print(" count: ");
            Serial.println(checkCount);
          #endif
        }
      } else {
        checkCount = 0;
      }
    } else {
      #ifdef DEBUG_MODE
        Serial.println("NO FIRE");
      #endif
    }
  if(checkCount >= FLAME_CHECK_TIMES_THRES) {
    handleOnFlameTriggered();
    checkCount = -1;  // prevent from retriggered until not checked
  }    


}
void FlameCheckTask(void* pvParameters) {
    uint8_t count=0;
    int32_t FirstPosX,FirstPosY,LastPosX,LastPosY;
    while (true) {

    // if (count == 0){
    //   FirstPosX = sys_position[0];
    //   FirstPosY = sys_position[1];       
    // }
    // count++;
    // if (count >= 100){
    //   if ((sys.state != State::Alarm && sys.state != State::Homing) || sys.state != State:) {
    //     if (sys_rt_exec_alarm == ExecAlarm::None) {
    //       if(FirstPosX == sys_position[0] && FirstPosY == sys_position[1]){
    //         BuzzerON();
    //         grbl_msg_sendf(CLIENT_SERIAL, MsgLevel::Info, "!!! TIMEOUT !!!  Laser spindle stay on ---POSX:%ld---POSY:%ld---",sys_position[0],sys_position[1]);
    //         spindle->deinit();
    //         count=0;
    //       }
    //       else
    //         count=0;
    //     }
    //   }
    // }
      flameSensorLoop();
      //BuzzerON();
      vTaskDelay(100 / portTICK_PERIOD_MS);    // delay a while
    }
}