#pragma once

#include "src/Grbl.h"
#include "ADXL345.h"
#include "src/Machines/lgt_ray5_v_0_1.h"
#include "src/longer_add/buzzer/buzzer.h"

// motion sensor pin initialization routine.
void initMotionSensor();
void motionSensorISR();
void handleOnMotionTriggered();
void motionSensorLoop();
void MotionCheckTask(void* pvParameters);