#include "temperature_sensor.h"

void handleOnTemperatureTriggered()
{
  if (sys.state != State::Alarm && sys.state != State::Homing) {
      if (sys_rt_exec_alarm == ExecAlarm::None) {
          grbl_msg_sendf(CLIENT_ALL, MsgLevel::Info, "!!!Warning!!! --------Temperature sensor");
          delay(100);
          mc_reset();  // Initiate system kill.
          // sys_rt_exec_alarm = ExecAlarm::HardLimit;  // Indicate hard limit critical event
          //�������
          // mc_homing_cycle( 0 );                      // Homing

          //������
          Serial.print("[WARNING]Temperature sensor on\xff\xff\xff\r\n");
          sys_rt_exec_alarm = ExecAlarm::TEMPERATURE;  // Indicate hard limit critical event
        //   sprintf(gcode, "g90x0y0\r\n");
        //   gc_execute_line(gcode, CLIENT_SERIAL);
          //Serial.println("g90x0y0", HEX)
      }
  }

#ifdef BUZZER_PIN
    BuzzerON();
#endif
}

void TemperatureCheckTask(void *pvParameters)
{
    while(true)
    {
        uint32_t adcValue = adc1_get_raw(TEMPERATURE_ADC_CHANNEL);
        // Serial.printf("Temperature ADC Value: %d\r\n", adcValue);
        static int checkCount = 0;
        if(PIN_EMPERATURE_USE_ADC) {
            const int frameRawReadTimes = 5;
            long frameRawSum = 0;

            for (int i = 0; i < frameRawReadTimes; i++)
                frameRawSum += adc1_get_raw(TEMPERATURE_ADC_CHANNEL);
            int frameRawRead = frameRawSum / frameRawReadTimes;
#ifdef TEMPERATURE_DEBUG
        // ��ӡ AD ֵ
            // Serial.printf("Temperature ADC Value: %d\r\n", adcValue);
#endif
            if (frameRawRead < TEMPERATURE_ADC_THRES) { 
                if (checkCount > -1) {
                    checkCount++;
#ifdef TEMPERATURE_DEBUG
                    Serial.print("Temperature: checked adc:");
                    Serial.print(frameRawRead);
                    Serial.print(" count: ");
                    Serial.println(checkCount);
#endif
                }
            } else {
                checkCount = 0;
            }
        }
        if(checkCount >= TEMPERATURE_CHECK_TIMES_THRES) {
            handleOnTemperatureTriggered();
            checkCount = -1;  // prevent from retriggered until not checked
        }    
        vTaskDelay(1000 / portTICK_PERIOD_MS);    // delay a while
    }
}

void TemperatureSensor_init(){

    adc1_config_width(ADC_WIDTH_BIT_12);          // ���� ADC λ��Ϊ 12 λ
    adc1_config_channel_atten(TEMPERATURE_ADC_CHANNEL, ADC_ATTEN_DB_11);  // ���� ADC ��������Ϊ 11 dB

    grbl_msg_sendf(CLIENT_ALL, MsgLevel::Info, "TemperatureSensor on pin %s", pinName(TEMPERATURE_PIN).c_str());
    xTaskCreate(TemperatureCheckTask,"TemperatureCheckTask", 2048, nullptr, 7, nullptr);
}