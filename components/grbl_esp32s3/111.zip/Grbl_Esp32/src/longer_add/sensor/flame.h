#pragma once

#include "src/Grbl.h"
#include <driver/adc.h>
#include "src/longer_add/buzzer/buzzer.h"
#include "src/Machines/lgt_ray5_v_0_1.h"

void FlameSensor_init();

void handleOnFlameTriggered();

void flameSensorLoop();
void FlameCheckTask(void* pvParameters);